CREATE TABLE caballos
(
codCaballo varchar2 (4),
nombre varchar2 (20) NOT NULL,
peso number (3),
fechaNacimiento DATE,
propietario varchar2 (25),
nacionalidad varchar2 (20),

CONSTRAINT PK_caballos PRIMARY KEY (codCaballo),
CONSTRAINT CHK_caballos CHECK (peso BETWEEN 240 AND 300),
CONSTRAINT CHK_caballosFecha CHECK (EXTRACT(YEAR FROM fechaNacimiento) > 2000),
CONSTRAINT CHK_caballosNacionalidad CHECK (nacionalidad=upper(nacionalidad))
);

CREATE TABLE carreras
(
codCarrera varchar2 (4),
fechaYhora DATE,
importePremio NUMBER (6),
apuestaLimite NUMBER (5,2),

CONSTRAINT PK_carreras PRIMARY KEY (codCarrera),
CONSTRAINT CHK_hora CHECK (EXTRACT(MONTH FROM fechaYhora) NOT IN (3,7)),
CONSTRAINT CHK_apuesta CHECK (apuestaLimite < 20000)
);

CREATE TABLE participaciones
(
codCaballo varchar2 (4),
codCarrera varchar2 (4),
dorsal NUMBER (2) NOT NULL,
jockey varchar2 (10) NOT NULL,
posicionFinal NUMBER (2),

CONSTRAINT PK_participaciones PRIMARY KEY (codCaballo, codCarrera),
CONSTRAINT FK_codCaballo FOREIGN KEY (codCaballo) REFERENCES caballos (codCaballo),
CONSTRAINT FK_codCarrera FOREIGN KEY (codCarrera) REFERENCES carreras (codCarrera)
);

CREATE TABLE clientes
(
dni varchar2 (10),
nombre varchar2 (20),
nacionalidad varchar2 (20),

CONSTRAINT PK_dni PRIMARY KEY (dni),
--CONSTRAINT CHK_clientes CHECK (regexp_like(*[0-9]{8}+[A-Z]{1})),
CONSTRAINT CHK_clientes2 CHECK (nacionalidad = upper(nacionalidad))
);

CREATE TABLE apuestas
(
dniCliente varchar2 (10),
codCaballo varchar2 (4),
codCarrera varchar2 (4),
importe NUMBER (6) DEFAULT 300 NOT NULL,
tantoPorUno NUMBER (4,2),

CONSTRAINT PK_apuestas PRIMARY KEY (dniCliente,codCaballo,codCarrera),
CONSTRAINT FK_cliente FOREIGN KEY (dniCliente) REFERENCES clientes (dni) ON DELETE CASCADE ,
CONSTRAINT FK_codCaballoAp FOREIGN KEY (codCaballo) REFERENCES caballos (codCaballo) ON DELETE CASCADE ,
CONSTRAINT FK_codCarreraAp FOREIGN KEY (codCarrera) REFERENCES carreras (codCarrera) ON DELETE CASCADE ,
CONSTRAINT CHK_apuestas CHECK (tantoPorUno > 1)
);


ALTER TABLE participaciones ADD CONSTRAINT CHK_nombres CHECK ((jockey) = initcap (jockey));

ALTER TABLE carreras ADD CONSTRAINT CHK_fechaYhora CHECK (fechaYhora > to_date('10/3','DD/MM') AND fechaYhora < to_date('10/11','DD/MM'));

ALTER TABLE caballos ADD CONSTRAINT CHK_caballoschk CHECK (nacionalidad IN ('Espa?ola','Brit?nica','?rabe')); 
ALTER TABLE caballos DROP COLUMN propietario;
ALTER TABLE carreras ADD CONSTRAINT CHL_importePremio CHECK (importePremio >= 1000);
ALTER TABLE clientes ADD codigo NUMBER (4) UNIQUE NOT NULL;
ALTER TABLE apuestas ADD premio NUMBER (10);
ALTER TABLE carreras disable CONSTRAINT CHL_importePremio;
--ALTER TABLE carreras DROP CONSTRAINT CHL_importePremio;

/*
DROP TABLE apuestas CASCADE CONSTRAINT;
DROP TABLE caballos CASCADE CONSTRAINT;
DROP TABLE clientes CASCADE CONSTRAINT;
DROP TABLE participaciones CASCADE CONSTRAINT;
DROP TABLE carreras CASCADE CONSTRAINT;
*/