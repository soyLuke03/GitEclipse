
CREATE TABLE clientes
(
dni varchar2(10),
nombre varchar2 (20) NOT NULL,
apellidos varchar2(30) NOT NULL,
ciudad varchar2(30) NOT NULL,

CONSTRAINT PK_clientes PRIMARY KEY (dni)
);

CREATE TABLE marcas
(
codMarca NUMBER(4),
nombre varchar2(20) NOT NULL,
pais varchar2(20) NOT null,

CONSTRAINT PK_marcas PRIMARY KEY (codMarca)
);

CREATE TABLE coches
(
codCoche number(4),
codMarca NUMBER (4),
modelo varchar2(20) NOT NULL,
matricula varchar2(8) NOT NULL,
color varchar2(20) NOT NULL,

CONSTRAINT PK_coches PRIMARY KEY (codCoche),
CONSTRAINT FK_codMarca FOREIGN KEY (codMarca) REFERENCES marcas (codMarca)
);

CREATE TABLE ventas
(
codCoche number(4),
cifc NUMBER (8) UNIQUE NOT NULL,
dni varchar2(10) NOT NULL,
fechaVenta DATE NOT NULL,
pvp number(10),

CONSTRAINT PK_ventas PRIMARY KEY (codCoche),
CONSTRAINT FK_ventas FOREIGN KEY (codCoche) REFERENCES coches (codCoche),
CONSTRAINT FK_dni FOREIGN KEY (dni) REFERENCES clientes (dni)
);

CREATE TABLE concesionarios
(
cifc NUMBER (8),
nombre varchar2 (20) NOT NULL,
ciudad varchar2 (30) NOT NULL,
cifcMatriz NUMBER (8) NOT NULL,

CONSTRAINT PK_concesionarios PRIMARY KEY (cifc),
CONSTRAINT FK_cifc FOREIGN KEY (cifc) REFERENCES ventas (cifc)
);
ALTER TABLE concesionarios ADD CONSTRAINT FK_reflex FOREIGN KEY (cifc) REFERENCES concesionarios (cifc);


CREATE TABLE distribucion
(
cifc NUMBER (8),
codCoche NUMBER (4),
fecha DATE NOT NULL,

CONSTRAINT PK_dist PRIMARY KEY (cifc, codCoche),
CONSTRAINT FK_dist1 FOREIGN KEY (cifc) REFERENCES ventas (cifc),
CONSTRAINT FK_dist2 FOREIGN KEY (codCoche) REFERENCES coches (codCoche)
);



ALTER TABLE ventas MODIFY fechaVenta DEFAULT sysdate;
ALTER TABLE coches ADD CONSTRAINT CHK_color CHECK (color IN ('rojo','amarillo','verde','ROJO','AMARILLO','VERDE'));
ALTER TABLE clientes ADD CONSTRAINT CHK_ciudad1 CHECK (ciudad = upper(ciudad));
ALTER TABLE concesionarios ADD CONSTRAINT CHK_ciudad2 CHECK (ciudad=upper(ciudad));
ALTER TABLE distribucion ADD area varchar2(20);
ALTER TABLE distribucion ADD CONSTRAINT CHK_area CHECK (area LIKE ('%T%'));
ALTER TABLE concesionarios disable CONSTRAINT FK_reflex;
ALTER TABLE concesionarios DROP CONSTRAINT FK_reflex;
